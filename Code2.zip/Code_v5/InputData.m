%---------------INPUT DATA----------------
%-----------------------------------------

%Domain lengths
%------------------------
domainPoints=[-1 1; 0 1];       %First  row for X dim
                                %Second row for Y dim                       
               

%Requested points (x: OUTLET)
%--------------------------
reqPoints=[0.1 0; 0.2 0; 0.3 0 ; 0.4 0;  0.5 0; 0.6 0; 0.7 0; 0.8 0; 0.9 0; 1 0]; %[x ; y] points

%Mesh sizes
%--------------------
meshSizes=[30 15];

%Initial properties
%---------------------
initProp=1;

%Boundary conditions
%----------------------
inletProp = [0 2];
outletProp = 0;
leftProp = 0;
rightProp = 0;
upperProp = 0;

%Time inputs
%---------------------
timeStep=8;
refTime=5.0e3;
maxtDiff=1e-4;

%Material properties
%---------------------
rhogamma=1000;
rho=1000;
cp=4;
k=170;

%Iterative solver parameters
%-----------------------------
maxIter=1e4;
maxDiff=1e-4;


%Postprocessor Options
PostProcess = 11;    % 0 for no plots
                     % 11 for evolutive plot


