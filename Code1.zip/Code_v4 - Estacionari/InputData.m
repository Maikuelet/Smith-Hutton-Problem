%---------------INPUT DATA----------------
%-----------------------------------------

%Domain lengths
%------------------------
domainPoints=[-1 1; 0 1];       %First  row for X dim
                                %Second row for Y dim                       
               

%Requested points (x: OUTLET)
%--------------------------
reqPoints=[0.1 0; 0.2 0; 0.3 0 ; 0.4 0;  0.5 0; 0.6 0; 0.7 0; 0.8 0; 0.9 0; 1 0]; %[x ; y] points

%Mesh sizes
%--------------------
meshSizes=[200 100];

%Initial properties
%---------------------
initProp=1;

%Boundary conditions
%----------------------
inletProp = [0 2];
outletProp = 0;
leftProp = 0;
rightProp = 0;
upperProp = 0;

%Time inputs
%---------------------
timeStep=5.0e2;
lastTime=1.0e6;
refTime=5.0e3;

%Material properties
%---------------------
rhogamma=1000000;
rho=1000000;
cp=4;
k=170;

%Iterative solver parameters
%-----------------------------
maxIter=1e4;
maxDiff=1e-4;


%Postprocessor Options
PostProcess = 1;    % 0 for no plots



